from setuptools import setup
# https://kiwidamien.github.io/making-a-python-package-vi-including-data-files.html
# https://python-packaging.readthedocs.io/en/latest/non-code-files.html
setup()

